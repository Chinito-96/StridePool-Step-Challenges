import SwiftUI

struct ChallengeListView: View {
    @State private var challenges: [Challenge] = []
    @State private var isLoading = true

    var body: some View {
        NavigationStack {
            List(challenges) { challenge in
                NavigationLink(value: challenge) {
                    ChallengeRow(challenge: challenge)
                }
            }
            .navigationTitle("Challenges")
            .navigationDestination(for: Challenge.self) { challenge in
                ChallengeDetailView(challenge: challenge)
            }
            .task { await load() }
            .refreshable { await load() }
            .overlay {
                if isLoading && challenges.isEmpty {
                    ProgressView()
                }
            }
        }
    }

    private func load() async {
        isLoading = true
        challenges = (try? await APIClient.shared.fetchChallenges()) ?? []
        isLoading = false
    }
}

struct ChallengeRow: View {
    let challenge: Challenge

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(challenge.title).font(.headline)
            HStack {
                Label("\(challenge.dailyStepGoal.map(String.init) ?? "Personalized") steps/day", systemImage: "figure.walk")
                Spacer()
                Text("$\(Double(challenge.entryFeeCents) / 100, specifier: "%.2f") entry")
            }
            .font(.subheadline)
            .foregroundStyle(.secondary)
            Text("Pool: $\(Double(challenge.poolTotalCents) / 100, specifier: "%.2f")")
                .font(.caption)
                .foregroundStyle(.green)
        }
        .padding(.vertical, 4)
    }
}

extension Challenge: Hashable {
    static func == (lhs: Challenge, rhs: Challenge) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}
