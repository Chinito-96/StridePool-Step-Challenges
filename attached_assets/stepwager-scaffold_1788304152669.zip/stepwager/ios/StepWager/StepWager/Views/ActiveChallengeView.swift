import SwiftUI

struct ActiveChallengeView: View {
    let entryId: String
    let dailyGoal: Int
    @StateObject private var healthKit = HealthKitManager()
    @State private var todaySteps = 0
    @State private var syncStatus: String = "Not synced yet"

    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.2), lineWidth: 12)
                Circle()
                    .trim(from: 0, to: min(CGFloat(todaySteps) / CGFloat(dailyGoal), 1.0))
                    .stroke(todaySteps >= dailyGoal ? Color.green : Color.blue, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack {
                    Text("\(todaySteps)").font(.largeTitle).bold()
                    Text("of \(dailyGoal) steps").font(.caption).foregroundStyle(.secondary)
                }
            }
            .frame(width: 220, height: 220)
            .padding()

            Text(syncStatus).font(.footnote).foregroundStyle(.secondary)

            Button("Sync now") { Task { await syncToday() } }
                .buttonStyle(.bordered)
        }
        .onAppear {
            healthKit.requestAuthorization { granted in
                if granted { Task { await syncToday() } }
            }
        }
        .navigationTitle("Today")
    }

    private func syncToday() async {
        syncStatus = "Syncing…"
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            healthKit.fetchSteps(for: Date()) { steps, samples in
                todaySteps = steps
                Task {
                    do {
                        let formatter = DateFormatter()
                        formatter.dateFormat = "yyyy-MM-dd"
                        try await APIClient.shared.submitSteps(
                            entryId: entryId,
                            date: formatter.string(from: Date()),
                            stepCount: steps,
                            samples: samples
                        )
                        syncStatus = "Synced just now"
                    } catch {
                        syncStatus = "Sync failed — will retry"
                    }
                    continuation.resume()
                }
            }
        }
    }
}
