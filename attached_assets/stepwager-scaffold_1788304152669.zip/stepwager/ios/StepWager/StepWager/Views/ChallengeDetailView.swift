import SwiftUI
import StripePaymentSheet

struct ChallengeDetailView: View {
    let challenge: Challenge
    @State private var paymentSheet: PaymentSheet?
    @State private var isJoining = false
    @State private var joinError: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(challenge.description)
                InfoRow(label: "Duration", value: "\(challenge.durationDays) days")
                InfoRow(label: "Daily goal", value: challenge.dailyStepGoal.map { "\($0) steps" } ?? "Personalized to you")
                InfoRow(label: "Entry fee", value: "$\(Double(challenge.entryFeeCents) / 100, specifier: "%.2f")")
                InfoRow(label: "Current pool", value: "$\(Double(challenge.poolTotalCents) / 100, specifier: "%.2f")")

                Text("If you complete every day's goal, you split the pool with everyone else who finishes. If you miss a day, you forfeit your entry — there's no additional penalty.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                if let joinError {
                    Text(joinError).foregroundStyle(.red).font(.footnote)
                }

                Button {
                    Task { await startJoinFlow() }
                } label: {
                    if isJoining {
                        ProgressView()
                    } else {
                        Text("Join for $\(Double(challenge.entryFeeCents) / 100, specifier: "%.2f")")
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isJoining)
            }
            .padding()
        }
        .navigationTitle(challenge.title)
    }

    /// Fetches a PaymentIntent client_secret from our backend, then hands it
    /// to Stripe's PaymentSheet. Card entry, validation, and 3DS all happen
    /// inside Stripe's SDK — this app never sees or stores raw card data.
    private func startJoinFlow() async {
        isJoining = true
        joinError = nil
        do {
            let clientSecret = try await APIClient.shared.joinChallenge(id: challenge.id)
            var config = PaymentSheet.Configuration()
            config.merchantDisplayName = "StepWager"
            let sheet = PaymentSheet(paymentIntentClientSecret: clientSecret, configuration: config)
            // In a full implementation, present `sheet` via
            // PaymentSheet.present(from:) and handle the completion result
            // (.completed / .canceled / .failed) to update local UI state.
            // The Entry itself is created server-side once Stripe's webhook
            // confirms payment_intent.succeeded — never trust the client
            // alone to say "I paid."
            self.paymentSheet = sheet
        } catch {
            joinError = "Couldn't start checkout. Please try again."
        }
        isJoining = false
    }
}

struct InfoRow: View {
    let label: String
    let value: String
    var body: some View {
        HStack {
            Text(label).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.medium)
        }
    }
}
