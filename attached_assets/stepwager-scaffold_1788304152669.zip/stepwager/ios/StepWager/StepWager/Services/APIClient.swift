import Foundation

struct Challenge: Codable, Identifiable {
    let id: String
    let title: String
    let description: String
    let entryFeeCents: Int
    let durationDays: Int
    let dailyStepGoal: Int?
    let goalType: String
    let startDate: String
    let status: String
    let poolTotalCents: Int
}

final class APIClient {
    static let shared = APIClient()
    // Point this at your deployed backend. Never hardcode production
    // secrets on-device — the app only ever talks to YOUR server, which
    // holds the real Stripe secret key.
    private let baseURL = URL(string: "https://api.stepwager.app")!
    private var authToken: String?

    func setAuthToken(_ token: String) { self.authToken = token }

    private func request(_ path: String, method: String = "GET", body: [String: Any]? = nil) -> URLRequest {
        var req = URLRequest(url: baseURL.appendingPathComponent(path))
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let body = body {
            req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }
        return req
    }

    func fetchChallenges() async throws -> [Challenge] {
        let (data, _) = try await URLSession.shared.data(for: request("/api/challenges"))
        return try JSONDecoder().decode([Challenge].self, from: data)
    }

    /// Kicks off payment for joining a challenge. Returns a Stripe
    /// PaymentIntent client_secret, which the caller hands to
    /// Stripe's PaymentSheet — card details never pass through this app's
    /// own code, only through Stripe's SDK.
    func joinChallenge(id: String) async throws -> String {
        let (data, _) = try await URLSession.shared.data(for: request("/api/challenges/\(id)/join", method: "POST"))
        struct Response: Codable { let clientSecret: String }
        return try JSONDecoder().decode(Response.self, from: data).clientSecret
    }

    func submitSteps(entryId: String, date: String, stepCount: Int, samples: [StepSample]) async throws {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        let samplesData = try encoder.encode(samples)
        let samplesArray = try JSONSerialization.jsonObject(with: samplesData) as? [[String: Any]]

        let body: [String: Any] = [
            "date": date,
            "stepCount": stepCount,
            "healthKitSamples": samplesArray ?? [],
        ]
        _ = try await URLSession.shared.data(for: request("/api/entries/\(entryId)/steps", method: "POST", body: body))
    }
}
