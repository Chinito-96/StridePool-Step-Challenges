import HealthKit
import Foundation

/// Wraps HealthKit access for reading daily step counts.
/// Add "Health" capability + NSHealthShareUsageDescription in Info.plist:
/// "StepWager reads your daily step count to verify challenge progress."
final class HealthKitManager: ObservableObject {
    private let healthStore = HKHealthStore()
    private let stepType = HKQuantityType.quantityType(forIdentifier: .stepCount)!

    @Published var authorized = false

    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false)
            return
        }
        healthStore.requestAuthorization(toShare: [], read: [stepType]) { [weak self] success, error in
            DispatchQueue.main.async {
                self?.authorized = success
                completion(success)
            }
        }
    }

    /// Fetches step count for a single calendar day, plus the raw hourly
    /// samples — the backend uses the samples for basic anti-cheat checks
    /// (e.g. implausible bursts of steps in a short window).
    func fetchSteps(for date: Date, completion: @escaping (Int, [StepSample]) -> Void) {
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: date)
        guard let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay) else {
            completion(0, [])
            return
        }
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: endOfDay, options: .strictStartDate)

        // Total for the day
        let sumQuery = HKStatisticsQuery(quantityType: stepType, quantitySamplePredicate: predicate, options: .cumulativeSum) { [weak self] _, statistics, _ in
            let total = Int(statistics?.sumQuantity()?.doubleValue(for: .count()) ?? 0)

            // Hourly breakdown for burst-rate sanity checking server-side.
            let hourlyQuery = HKStatisticsCollectionQuery(
                quantityType: self?.stepType ?? HKQuantityType.quantityType(forIdentifier: .stepCount)!,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum,
                anchorDate: startOfDay,
                intervalComponents: DateComponents(minute: 60)
            )
            hourlyQuery.initialResultsHandler = { _, collection, _ in
                var samples: [StepSample] = []
                collection?.enumerateStatistics(from: startOfDay, to: endOfDay) { stat, _ in
                    let value = Int(stat.sumQuantity()?.doubleValue(for: .count()) ?? 0)
                    if value > 0 {
                        samples.append(StepSample(startDate: stat.startDate, endDate: stat.endDate, value: value))
                    }
                }
                DispatchQueue.main.async {
                    completion(total, samples)
                }
            }
            self?.healthStore.execute(hourlyQuery)
        }
        healthStore.execute(sumQuery)
    }
}

struct StepSample: Codable {
    let startDate: Date
    let endDate: Date
    let value: Int
}
