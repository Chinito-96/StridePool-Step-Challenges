# StepWager — scaffold

A starting point for a Steppa-style step-challenge app: users pay an entry
fee, hit a daily step goal (verified via HealthKit), and finishers split the
pool. This is a working scaffold, not a finished product — see "What's left"
below.

## Structure

```
backend/    Node/Express API — challenges, payments (Stripe), settlement, anti-cheat
ios/        SwiftUI iOS app — challenge browsing, HealthKit sync, Stripe PaymentSheet
```

## Where you can differentiate from Steppa

- **Personalized goals** (`goalType: 'personalized'` is already modeled) instead of
  one-size-fits-all targets — likely improves fairness and completion rates.
- **Zero platform fee, stated upfront** — fee complaints were Steppa's biggest
  visible pain point in reviews.
- **Android**, which Steppa doesn't have yet.
- **Stronger anti-cheat** — `routes/steps.js` has basic heuristics
  (implausible daily totals, burst-rate checks); this is the area most worth
  investing in, since trust in the step data is the whole product.
- **No-finisher policy stated clearly in the UI**, not buried in ToS — the
  settlement logic already forces you to pick one (see `settlementService.js`).

## Running the backend locally

```bash
cd backend
cp .env.example .env   # fill in your own Stripe TEST keys
npm install
npm run dev
```

You'll need:
- A Postgres database (`DATABASE_URL`)
- A **Stripe account** (free) → test keys from the Stripe dashboard
- Stripe CLI for local webhook testing: `stripe listen --forward-to localhost:4000/api/webhooks/stripe`

## Running the iOS app

Open `ios/StepWager` in Xcode (15+), add the Stripe iOS SDK
(`StripePaymentSheet` via Swift Package Manager), enable the HealthKit
capability, and point `APIClient.baseURL` at your local backend.

## What's left before this could actually launch

**Legal/compliance — do this before writing another line of product code:**
- Real-money pooled contests based on personal step performance sit in
  "skill-based contest" territory, which is regulated differently
  state-by-state in the US — several states restrict or effectively
  prohibit this model. You need a lawyer to review this specific mechanic
  against each state you plan to operate in, not just general App Store
  guidelines.
- Holding user funds before payout can trigger money-transmission licensing
  requirements depending on your structure — how you route funds through
  Stripe (e.g., Connect vs. holding funds on your own platform balance)
  affects this.
- Age/ID verification (`idVerified` in the User model is a placeholder) —
  you need a real KYC flow before allowing paid entry, not just a checkbox.
- Terms of service covering the no-finisher pool policy, refund policy, and
  dispute resolution for step-count disagreements.

**Product/engineering:**
- Payout onboarding UI (Stripe Connect Express) — users can't get paid until
  they complete this.
- Personalized goal calculation from step history.
- Push notifications for daily reminders / streak risk.
- Admin tooling to review `flaggedSuspicious` step records manually.
- Real auth (the scaffold assumes `req.user` is set by middleware you still
  need to write — JWT is in the dependency list to get you started).

This is enough to demo the core loop and iterate on UI/UX. Treat the
payment and settlement code as a first draft to review carefully — real
money makes bugs expensive.
