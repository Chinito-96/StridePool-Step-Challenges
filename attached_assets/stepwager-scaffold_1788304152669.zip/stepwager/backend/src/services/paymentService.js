// paymentService.js
// Wraps Stripe for the two money movements this app needs:
//   1. COLLECTING entry fees from a user   -> PaymentIntents (Stripe.js on the client)
//   2. PAYING OUT winnings to a user       -> Stripe Connect Transfers (Express accounts)
//
// IMPORTANT: (2) requires you to be approved for Stripe Connect and each
// user to complete Connect onboarding (to receive payouts to their bank).
// This is a materially bigger compliance lift than just accepting payments —
// budget time for it. Until Connect is live, treat payouts as "credited to
// in-app wallet balance" and handle actual cash-out manually or via a
// simpler rail (e.g. PayPal Payouts API) — a stub for that is included below.

const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

/**
 * Create a PaymentIntent for a user joining a challenge.
 * The client (iOS app) uses the returned client_secret with Stripe's
 * PaymentSheet to collect card details — raw card numbers should NEVER
 * touch your own server.
 */
async function createEntryFeePaymentIntent({ user, challenge }) {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: challenge.entryFeeCents,
    currency: 'usd',
    customer: user.stripeCustomerId,
    metadata: {
      userId: user.id,
      challengeId: challenge.id,
      purpose: 'challenge_entry_fee',
    },
    // Prevents a user's card being charged twice for a double-tapped join
    // by letting the client pass the same idempotency key on retry.
    automatic_payment_methods: { enabled: true },
  });
  return paymentIntent;
}

/**
 * Pay out a user's winnings via Stripe Connect once a challenge settles.
 * Requires user.stripeConnectAccountId (set after Connect onboarding).
 */
async function payoutWinnings({ user, amountCents, challengeId }) {
  if (!user.stripeConnectAccountId) {
    throw new Error('User has not completed payout onboarding (Stripe Connect).');
  }
  const transfer = await stripe.transfers.create({
    amount: amountCents,
    currency: 'usd',
    destination: user.stripeConnectAccountId,
    metadata: { challengeId, userId: user.id, purpose: 'challenge_payout' },
  });
  return transfer;
}

/**
 * Verify a webhook came from Stripe before trusting it (e.g. payment_intent.succeeded).
 * Mount the webhook route with express.raw({type: 'application/json'}), not express.json().
 */
function constructWebhookEvent(rawBody, signature) {
  return stripe.webhooks.constructEvent(
    rawBody,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET
  );
}

module.exports = { createEntryFeePaymentIntent, payoutWinnings, constructWebhookEvent };
