// settlementService.js
// Runs once a challenge's final day has passed. Determines who finished,
// splits the pool, and triggers payouts. This is the core "differentiator"
// logic — keep it deterministic, auditable, and covered by tests before
// real money ever touches it.

const { Entry, DailyStepRecord, Challenge } = require('../models');
const { payoutWinnings } = require('./paymentService');

async function settleChallenge(challengeId) {
  const challenge = await Challenge.findByPk(challengeId, {
    include: [{ model: Entry, include: [DailyStepRecord] }],
  });
  if (!challenge) throw new Error('Challenge not found');
  if (challenge.status === 'completed') return challenge;

  const entries = challenge.Entries;
  const finishers = [];
  const nonFinishers = [];

  for (const entry of entries) {
    const days = entry.DailyStepRecords;
    const requiredDays = challenge.durationDays;
    const daysMet = days.filter((d) => d.goalMet && !d.flaggedSuspicious).length;
    const finished = daysMet >= requiredDays;

    if (finished) {
      finishers.push(entry);
    } else {
      nonFinishers.push(entry);
      entry.status = 'failed';
    }
  }

  // Pool = sum of ALL entry fees, including those who failed/dropped —
  // this is the core mechanic that makes finishers' share grow as more
  // people miss the goal. Be transparent about this in the UI; it's the
  // single most-scrutinized part of apps like this.
  const poolCents = entries.reduce((sum, e) => sum + (e.stripePaymentIntentId ? challenge.entryFeeCents : 0), 0);

  if (finishers.length === 0) {
    // Edge case Steppa-style apps must handle explicitly: nobody finished.
    // Common approaches: roll the pool into the next challenge, refund
    // everyone, or donate — decide and disclose this upfront in your terms.
    challenge.status = 'completed';
    await challenge.save();
    return { challenge, finishers: [], nonFinishers, poolCents, note: 'No finishers — apply your stated no-finisher policy.' };
  }

  const shareCents = Math.floor(poolCents / finishers.length);
  const remainderCents = poolCents - shareCents * finishers.length; // rounding dust

  for (let i = 0; i < finishers.length; i++) {
    const entry = finishers[i];
    const payout = shareCents + (i === 0 ? remainderCents : 0); // give rounding remainder to one finisher, deterministically
    entry.status = 'completed';
    entry.payoutCents = payout;
    await entry.save();

    // Credit wallet first (source of truth), then attempt real payout.
    // Decoupling these means a failed Stripe transfer doesn't lose the record
    // of what's owed — retry payout independently of settlement.
    const user = await entry.getUser();
    user.walletBalanceCents += payout;
    await user.save();

    try {
      await payoutWinnings({ user, amountCents: payout, challengeId: challenge.id });
    } catch (err) {
      // Log and continue — don't let one user's missing Connect account
      // block settlement for everyone else.
      console.error(`Payout failed for user ${user.id}:`, err.message);
    }
  }

  for (const entry of nonFinishers) await entry.save();

  challenge.status = 'completed';
  await challenge.save();

  return { challenge, finishers, nonFinishers, poolCents, shareCents };
}

module.exports = { settleChallenge };
