const express = require('express');
const router = express.Router();
const { constructWebhookEvent } = require('../services/paymentService');
const { finalizeEntry } = require('./challenges');

// Mounted with express.raw({ type: 'application/json' }) in server.js —
// Stripe's signature check needs the exact raw request body.
router.post('/webhooks/stripe', async (req, res) => {
  let event;
  try {
    event = constructWebhookEvent(req.body, req.headers['stripe-signature']);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const pi = event.data.object;
      await finalizeEntry({
        userId: pi.metadata.userId,
        challengeId: pi.metadata.challengeId,
        paymentIntentId: pi.id,
      });
      break;
    }
    case 'payment_intent.payment_failed': {
      console.warn('Payment failed:', event.data.object.id);
      break;
    }
    default:
      break; // ignore other event types
  }

  res.json({ received: true });
});

module.exports = router;
