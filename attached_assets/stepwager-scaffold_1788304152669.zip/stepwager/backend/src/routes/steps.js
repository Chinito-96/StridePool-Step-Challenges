// routes/steps.js
// Receives daily step data synced from the iOS app's HealthKit reader.
// Anti-cheat is the single biggest technical risk in this category of app —
// this file implements basic heuristic checks; treat it as a starting point,
// not a finished system.

const express = require('express');
const router = express.Router();
const { Entry, DailyStepRecord } = require('../models');

const MAX_PLAUSIBLE_STEPS_PER_DAY = 60000; // ~30 miles of walking; flag above this
const MAX_STEPS_PER_MINUTE_BURST = 250;    // sanity check if HealthKit gives intraday samples

router.post('/entries/:entryId/steps', async (req, res) => {
  const { entryId } = req.params;
  const { date, stepCount, healthKitSamples } = req.body;
  // healthKitSamples (optional): array of { startDate, endDate, value }
  // pulled straight from HKStatisticsQuery — keeping the raw samples lets
  // you re-run fraud checks later without re-syncing from the device.

  const entry = await Entry.findByPk(entryId, { include: 'Challenge' });
  if (!entry) return res.status(404).json({ error: 'Entry not found' });

  let flagged = false;
  let flagReason = null;

  if (stepCount > MAX_PLAUSIBLE_STEPS_PER_DAY) {
    flagged = true;
    flagReason = 'exceeds_plausible_daily_max';
  }

  if (Array.isArray(healthKitSamples)) {
    for (const sample of healthKitSamples) {
      const minutes = (new Date(sample.endDate) - new Date(sample.startDate)) / 60000;
      if (minutes > 0 && sample.value / minutes > MAX_STEPS_PER_MINUTE_BURST) {
        flagged = true;
        flagReason = 'implausible_burst_rate';
        break;
      }
    }
  }

  // Also worth adding later: compare against device motion coprocessor data,
  // check for step counts written instantly vs. accumulated through the day
  // (HealthKit lets you see when a sample was actually recorded), and rate-limit
  // how far in the past a "backfilled" step entry can be submitted.

  const goalMet = entry.personalizedGoal
    ? stepCount >= entry.personalizedGoal
    : stepCount >= entry.Challenge.dailyStepGoal;

  const record = await DailyStepRecord.create({
    date,
    stepCount,
    goalMet: goalMet && !flagged,
    sourceRaw: { stepCount, healthKitSamples },
    flaggedSuspicious: flagged,
    flagReason,
    EntryId: entry.id,
  });

  res.json({ record, flagged });
});

module.exports = router;
