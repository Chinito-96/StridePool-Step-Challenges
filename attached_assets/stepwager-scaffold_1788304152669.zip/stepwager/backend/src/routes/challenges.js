const express = require('express');
const router = express.Router();
const { Challenge, Entry, User } = require('../models');
const { createEntryFeePaymentIntent } = require('../services/paymentService');

// Browse open challenges
router.get('/challenges', async (req, res) => {
  const challenges = await Challenge.findAll({ where: { status: ['upcoming', 'active'] } });
  res.json(challenges);
});

// Start joining a challenge: creates a PaymentIntent, does NOT create the
// Entry yet — the Entry is created only after payment succeeds (via webhook)
// so a user can never occupy a slot / count toward the pool without paying.
router.post('/challenges/:id/join', async (req, res) => {
  const user = req.user; // set by auth middleware
  const challenge = await Challenge.findByPk(req.params.id);
  if (!challenge) return res.status(404).json({ error: 'Not found' });

  if (!user.idVerified) {
    return res.status(403).json({ error: 'Identity/age verification required before joining a paid challenge.' });
  }
  if (challenge.stateRestriction?.blockedStates?.includes(user.state)) {
    return res.status(403).json({ error: 'This challenge is not available in your state.' });
  }

  const paymentIntent = await createEntryFeePaymentIntent({ user, challenge });
  res.json({ clientSecret: paymentIntent.client_secret });
});

// Called by the Stripe webhook handler on payment_intent.succeeded
async function finalizeEntry({ userId, challengeId, paymentIntentId }) {
  const challenge = await Challenge.findByPk(challengeId);
  const entry = await Entry.create({
    UserId: userId,
    ChallengeId: challengeId,
    stripePaymentIntentId: paymentIntentId,
    paidAt: new Date(),
    status: 'active',
    personalizedGoal: challenge.goalType === 'personalized' ? null : undefined, // TODO: compute from user history
  });
  challenge.poolTotalCents += challenge.entryFeeCents;
  await challenge.save();
  return entry;
}

module.exports = { router, finalizeEntry };
