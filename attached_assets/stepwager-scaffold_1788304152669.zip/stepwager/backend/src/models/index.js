const { Sequelize, DataTypes } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: 'postgres',
  logging: false,
});

// --- User ---
// Real-money apps require identity + age verification before allowing
// paid challenges. dateOfBirth + idVerified are placeholders for that flow
// (e.g. Stripe Identity or Persona) — do not let users join paid challenges
// without idVerified === true.
const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  email: { type: DataTypes.STRING, unique: true, allowNull: false },
  passwordHash: { type: DataTypes.STRING, allowNull: false },
  displayName: DataTypes.STRING,
  dateOfBirth: DataTypes.DATEONLY,
  idVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
  stripeCustomerId: DataTypes.STRING,      // for taking payments (entry fees)
  stripeConnectAccountId: DataTypes.STRING, // for sending payouts (winnings)
  walletBalanceCents: { type: DataTypes.INTEGER, defaultValue: 0 },
  state: DataTypes.STRING, // US state of residence — needed for eligibility gating
});

// --- Challenge ---
const Challenge = sequelize.define('Challenge', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  title: DataTypes.STRING,
  description: DataTypes.TEXT,
  entryFeeCents: DataTypes.INTEGER,
  durationDays: DataTypes.INTEGER,
  dailyStepGoal: DataTypes.INTEGER, // null if personalized goals are used instead
  goalType: {
    type: DataTypes.ENUM('fixed', 'personalized'),
    defaultValue: 'fixed',
  },
  startDate: DataTypes.DATEONLY,
  status: {
    type: DataTypes.ENUM('upcoming', 'active', 'settling', 'completed', 'canceled'),
    defaultValue: 'upcoming',
  },
  poolTotalCents: { type: DataTypes.INTEGER, defaultValue: 0 },
  stateRestriction: DataTypes.JSONB, // e.g. { blockedStates: ['WA','AZ',...] }
});

// --- Entry (a user joining a challenge) ---
const Entry = sequelize.define('Entry', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  status: {
    type: DataTypes.ENUM('active', 'failed', 'completed', 'refunded'),
    defaultValue: 'active',
  },
  personalizedGoal: DataTypes.INTEGER, // per-user daily goal if goalType === 'personalized'
  stripePaymentIntentId: DataTypes.STRING,
  paidAt: DataTypes.DATE,
  payoutCents: DataTypes.INTEGER,
});

// --- DailyStepRecord ---
// One row per user per challenge day. sourceRaw retains the original
// HealthKit payload for audit / anti-fraud review.
const DailyStepRecord = sequelize.define('DailyStepRecord', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  date: DataTypes.DATEONLY,
  stepCount: DataTypes.INTEGER,
  goalMet: DataTypes.BOOLEAN,
  sourceRaw: DataTypes.JSONB,
  flaggedSuspicious: { type: DataTypes.BOOLEAN, defaultValue: false },
  flagReason: DataTypes.STRING,
});

User.hasMany(Entry);
Entry.belongsTo(User);
Challenge.hasMany(Entry);
Entry.belongsTo(Challenge);
Entry.hasMany(DailyStepRecord);
DailyStepRecord.belongsTo(Entry);

module.exports = { sequelize, User, Challenge, Entry, DailyStepRecord };
