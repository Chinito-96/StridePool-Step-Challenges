require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');

const { sequelize, Challenge } = require('./models');
const { router: challengesRouter } = require('./routes/challenges');
const stepsRouter = require('./routes/steps');
const webhooksRouter = require('./routes/webhooks');
const { settleChallenge } = require('./services/settlementService');

const app = express();

// Stripe webhook needs the RAW body for signature verification, so it must
// be mounted BEFORE express.json() strips/parses the body.
app.use('/api', webhooksRouter);

app.use(cors());
app.use(express.json());
app.use('/api', challengesRouter);
app.use('/api', stepsRouter);

// Nightly job: settle any challenge whose final day has passed.
// In production, move this to a proper job queue (e.g. BullMQ) so a crashed
// process doesn't silently skip a day's settlement run.
cron.schedule('0 3 * * *', async () => {
  const challenge = await Challenge.findAll({ where: { status: 'active' } });
  for (const c of challenge) {
    const endDate = new Date(c.startDate);
    endDate.setDate(endDate.getDate() + c.durationDays);
    if (new Date() >= endDate) {
      console.log(`Settling challenge ${c.id}`);
      await settleChallenge(c.id);
    }
  }
});

const PORT = process.env.PORT || 4000;

sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`StepWager backend running on :${PORT}`));
});
